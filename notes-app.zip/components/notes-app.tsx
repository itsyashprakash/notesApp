"use client"

import { useState } from "react"
import {
  Search,
  Plus,
  FileText,
  Star,
  Archive,
  Trash,
  Tag,
  FolderClosed,
  ChevronDown,
  SlidersHorizontal,
  Calendar,
} from "lucide-react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { ScrollArea } from "@/components/ui/scroll-area"
import { useNotesStore } from "@/lib/store"
import NoteEditor from "@/components/note-editor"
import NoteList from "@/components/note-list"
import CalendarView from "@/components/calendar-view"
import EmptyNoteState from "@/components/empty-note-state"
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog"
import { Label } from "@/components/ui/label"
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from "@/components/ui/tooltip"
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog"
import { Toaster } from "sonner"
import { motion, AnimatePresence } from "framer-motion"

export default function NotesApp() {
  const {
    notes,
    tags,
    activeNote,
    activeView,
    activeTag,
    addNote,
    addTag,
    setActiveView,
    setActiveNote,
    emptyTrash,
    activeDate,
    setActiveDate,
  } = useNotesStore()

  const [searchTagsQuery, setSearchTagsQuery] = useState("")
  const [searchNotesQuery, setSearchNotesQuery] = useState("")
  const [isTagDialogOpen, setIsTagDialogOpen] = useState(false)
  const [newTagName, setNewTagName] = useState("")
  const [isTrashDialogOpen, setIsTrashDialogOpen] = useState(false)

  // Filter notes based on active view and search query
  const filteredNotes = notes.filter((note) => {
    // First filter by view
    let viewMatch = false

    switch (activeView) {
      case "notes":
        viewMatch = !note.isDeleted && !note.isArchived && note.type === "note"
        break
      case "starred":
        viewMatch = !note.isDeleted && note.isStarred
        break
      case "archived":
        viewMatch = !note.isDeleted && note.isArchived
        break
      case "trash":
        viewMatch = note.isDeleted
        break
      case "untagged":
        viewMatch = !note.isDeleted && !note.isArchived && note.tags.length === 0
        break
      case "tag":
        viewMatch = !note.isDeleted && !note.isArchived && activeTag ? note.tags.includes(activeTag) : false
        break
      case "calendar":
        viewMatch = !note.isDeleted && !note.isArchived
        break
    }

    // Then filter by search query
    const searchMatch =
      searchNotesQuery === "" ||
      note.title.toLowerCase().includes(searchNotesQuery.toLowerCase()) ||
      note.content.toLowerCase().includes(searchNotesQuery.toLowerCase())

    return viewMatch && searchMatch
  })

  // Filter tags based on search query
  const filteredTags = tags.filter(
    (tag) => searchTagsQuery === "" || tag.name.toLowerCase().includes(searchTagsQuery.toLowerCase()),
  )

  // Count notes for each view
  const notesCount = notes.filter((n) => !n.isDeleted && !n.isArchived && n.type === "note").length

  // Create a new note
  const handleAddNote = () => {
    const tags = activeView === "tag" && activeTag ? [activeTag] : []
    addNote({ tags })
  }

  // Create a new folder
  const handleAddFolder = () => {
    if (newTagName.trim()) {
      addTag({ name: newTagName.trim(), type: "folder" })
      setNewTagName("")
      setIsTagDialogOpen(false)
    }
  }

  // Handle empty trash confirmation
  const handleEmptyTrash = () => {
    emptyTrash()
    setIsTrashDialogOpen(false)
  }

  // Get the active note object
  const currentNote = notes.find((note) => note.id === activeNote)

  // Get view title
  const getViewTitle = () => {
    switch (activeView) {
      case "notes":
        return "Notes"
      case "starred":
        return "Starred"
      case "archived":
        return "Archived"
      case "trash":
        return "Trash"
      case "untagged":
        return "Untagged"
      case "tag":
        const tag = tags.find((t) => t.id === activeTag)
        return tag ? tag.name : "Section"
      case "calendar":
        return "Calendar"
    }
  }

  return (
    <div className="flex h-screen bg-background">
      {/* Sidebar */}
      <motion.div
        className="w-64 border-r bg-gray-50 flex flex-col"
        initial={{ x: -60, opacity: 0 }}
        animate={{ x: 0, opacity: 1 }}
        transition={{ duration: 0.3, ease: "easeOut" }}
      >
        <div className="p-4">
          <div className="relative">
            <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
            <Input
              type="search"
              placeholder="Search sections..."
              className="pl-8 bg-white rounded-lg"
              value={searchTagsQuery}
              onChange={(e) => setSearchTagsQuery(e.target.value)}
            />
          </div>
        </div>

        <div className="px-4 py-2 flex justify-between items-center">
          <h2 className="text-sm font-medium text-gray-700">Views</h2>
          <TooltipProvider>
            <Tooltip>
              <TooltipTrigger asChild>
                <Button variant="ghost" size="icon" className="h-6 w-6 text-gray-500 hover:text-gray-700">
                  <Plus className="h-4 w-4" />
                </Button>
              </TooltipTrigger>
              <TooltipContent>
                <p>Add custom view</p>
              </TooltipContent>
            </Tooltip>
          </TooltipProvider>
        </div>

        <nav className="space-y-1 px-2">
          <Button
            variant={activeView === "notes" ? "secondary" : "ghost"}
            className="w-full justify-start gap-2 font-normal rounded-lg"
            onClick={() => setActiveView("notes")}
          >
            <FileText className="h-4 w-4" />
            Notes
            <span className="ml-auto text-muted-foreground bg-gray-200 px-2 py-0.5 rounded-full text-xs">
              {notesCount}
            </span>
          </Button>
          <Button
            variant={activeView === "calendar" ? "secondary" : "ghost"}
            className="w-full justify-start gap-2 font-normal rounded-lg"
            onClick={() => setActiveView("calendar")}
          >
            <Calendar className="h-4 w-4" />
            Calendar
          </Button>
          <Button
            variant={activeView === "starred" ? "secondary" : "ghost"}
            className="w-full justify-start gap-2 font-normal rounded-lg"
            onClick={() => setActiveView("starred")}
          >
            <Star className="h-4 w-4" />
            Starred
          </Button>
          <Button
            variant={activeView === "archived" ? "secondary" : "ghost"}
            className="w-full justify-start gap-2 font-normal rounded-lg"
            onClick={() => setActiveView("archived")}
          >
            <Archive className="h-4 w-4" />
            Archived
          </Button>
          <Button
            variant={activeView === "trash" ? "secondary" : "ghost"}
            className="w-full justify-start gap-2 font-normal rounded-lg"
            onClick={() => setActiveView("trash")}
          >
            <Trash className="h-4 w-4" />
            Trash
          </Button>
          <Button
            variant={activeView === "untagged" ? "secondary" : "ghost"}
            className="w-full justify-start gap-2 font-normal rounded-lg"
            onClick={() => setActiveView("untagged")}
          >
            <Tag className="h-4 w-4" />
            Untagged
          </Button>
        </nav>

        <div className="mt-6 px-4 py-2 flex justify-between items-center">
          <div className="flex items-center gap-1">
            <h2 className="text-sm font-medium text-gray-700">Sections</h2>
            <ChevronDown className="h-3.5 w-3.5 text-gray-500" />
          </div>
          <TooltipProvider>
            <Tooltip>
              <TooltipTrigger asChild>
                <Button
                  variant="ghost"
                  size="icon"
                  className="h-6 w-6 text-gray-500 hover:text-gray-700"
                  onClick={() => setIsTagDialogOpen(true)}
                >
                  <Plus className="h-4 w-4" />
                </Button>
              </TooltipTrigger>
              <TooltipContent>
                <p>Add new section</p>
              </TooltipContent>
            </Tooltip>
          </TooltipProvider>
        </div>

        {filteredTags.length > 0 ? (
          <ScrollArea className="flex-1">
            <div className="space-y-1 px-2">
              <AnimatePresence>
                {filteredTags.map((tag) => (
                  <motion.div
                    key={tag.id}
                    initial={{ opacity: 0, y: 10 }}
                    animate={{ opacity: 1, y: 0 }}
                    exit={{ opacity: 0, y: -10 }}
                    transition={{ duration: 0.2 }}
                  >
                    <Button
                      variant={activeView === "tag" && activeTag === tag.id ? "secondary" : "ghost"}
                      className="w-full justify-start gap-2 font-normal rounded-lg"
                      onClick={() => setActiveView("tag", tag.id)}
                    >
                      <FolderClosed className="h-4 w-4" />
                      {tag.name}
                    </Button>
                  </motion.div>
                ))}
              </AnimatePresence>
            </div>
          </ScrollArea>
        ) : (
          <div className="px-4 py-2 text-xs text-muted-foreground">
            No sections. Create one using the add button above.
          </div>
        )}
      </motion.div>

      {/* Main Content */}
      <div className="flex-1 flex flex-col">
        {activeView !== "calendar" && (
          <>
            <motion.header
              className="border-b p-4 flex items-center justify-between bg-white shadow-sm"
              initial={{ y: -20, opacity: 0 }}
              animate={{ y: 0, opacity: 1 }}
              transition={{ duration: 0.3, ease: "easeOut", delay: 0.1 }}
            >
              <div className="flex items-center gap-2">
                <h1 className="text-xl font-medium">{getViewTitle()}</h1>
                <Button variant="ghost" size="icon" className="h-8 w-8 text-gray-500">
                  <SlidersHorizontal className="h-4 w-4" />
                </Button>
              </div>

              <div className="flex items-center gap-2">
                {activeView === "trash" && (
                  <TooltipProvider>
                    <Tooltip>
                      <TooltipTrigger asChild>
                        <Button variant="outline" size="sm" onClick={() => setIsTrashDialogOpen(true)}>
                          Empty Trash
                        </Button>
                      </TooltipTrigger>
                      <TooltipContent>
                        <p>Permanently delete all notes in trash</p>
                      </TooltipContent>
                    </Tooltip>
                  </TooltipProvider>
                )}

                <Button
                  size="icon"
                  className="rounded-full bg-blue-500 hover:bg-blue-600 shadow-md"
                  onClick={handleAddNote}
                  disabled={activeView === "trash" || activeView === "archived"}
                >
                  <Plus className="h-4 w-4" />
                </Button>
              </div>
            </motion.header>

            <div className="p-4 border-b bg-white">
              <div className="relative">
                <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
                <Input
                  type="search"
                  placeholder="Search..."
                  className="pl-8 rounded-lg"
                  value={searchNotesQuery}
                  onChange={(e) => setSearchNotesQuery(e.target.value)}
                />
              </div>
            </div>
          </>
        )}

        <div className="flex-1 flex">
          {activeView === "calendar" ? (
            <div className="flex-1">
              <CalendarView />
            </div>
          ) : (
            <>
              {/* Note List */}
              <NoteList notes={filteredNotes} activeNoteId={activeNote} onSelectNote={setActiveNote} />

              {/* Note Editor or Empty State */}
              <AnimatePresence mode="wait">
                {currentNote ? (
                  <motion.div
                    key={currentNote.id}
                    initial={{ opacity: 0, x: 20 }}
                    animate={{ opacity: 1, x: 0 }}
                    exit={{ opacity: 0, x: 20 }}
                    transition={{ duration: 0.2 }}
                    className="flex-1"
                  >
                    <NoteEditor note={currentNote} />
                  </motion.div>
                ) : (
                  <motion.div
                    key="empty-state"
                    initial={{ opacity: 0 }}
                    animate={{ opacity: 1 }}
                    exit={{ opacity: 0 }}
                    transition={{ duration: 0.2 }}
                    className="flex-1"
                  >
                    <EmptyNoteState onCreateNote={handleAddNote} />
                  </motion.div>
                )}
              </AnimatePresence>
            </>
          )}
        </div>
      </div>

      {/* Add Section Dialog */}
      <Dialog open={isTagDialogOpen} onOpenChange={setIsTagDialogOpen}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle>Create New Section</DialogTitle>
          </DialogHeader>
          <div className="space-y-4 py-2">
            <div className="space-y-2">
              <Label htmlFor="name">Name</Label>
              <Input
                id="name"
                placeholder="Enter section name"
                value={newTagName}
                onChange={(e) => setNewTagName(e.target.value)}
                className="rounded-lg"
              />
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setIsTagDialogOpen(false)} className="rounded-lg">
              Cancel
            </Button>
            <Button onClick={handleAddFolder} className="rounded-lg">
              Create
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Empty Trash Confirmation Dialog */}
      <AlertDialog open={isTrashDialogOpen} onOpenChange={setIsTrashDialogOpen}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Empty Trash?</AlertDialogTitle>
            <AlertDialogDescription>
              This action cannot be undone. This will permanently delete all notes in the trash.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel className="rounded-lg">Cancel</AlertDialogCancel>
            <AlertDialogAction onClick={handleEmptyTrash} className="bg-red-500 hover:bg-red-600 rounded-lg">
              Empty Trash
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>

      <Toaster position="top-right" />
    </div>
  )
}
