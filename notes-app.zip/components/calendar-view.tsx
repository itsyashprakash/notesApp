"use client"

import React from "react"
import { useState, useEffect } from "react"
import { useNotesStore } from "@/lib/store"
import { Button } from "@/components/ui/button"
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog"
import { Label } from "@/components/ui/label"
import { Input } from "@/components/ui/input"
import { Textarea } from "@/components/ui/textarea"
import { ScrollArea } from "@/components/ui/scroll-area"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import {
  format,
  startOfMonth,
  endOfMonth,
  eachDayOfInterval,
  isSameMonth,
  isSameDay,
  addMonths,
  subMonths,
  getDay,
  addDays,
  parseISO,
  isToday,
  startOfWeek,
  endOfWeek,
  isSameWeek,
} from "date-fns"
import { Plus, Bell, ChevronLeft, ChevronRight, TagIcon, Edit, Trash2, AlertCircle } from "lucide-react"
import { toast } from "sonner"
import { motion, AnimatePresence } from "framer-motion"

export default function CalendarView() {
  const { events, addEvent, updateEvent, deleteEvent, tags, addTag, updateTag, deleteTag } = useNotesStore()
  const [isEventDialogOpen, setIsEventDialogOpen] = useState(false)
  const [isDeleteDialogOpen, setIsDeleteDialogOpen] = useState(false)
  const [isTagDialogOpen, setIsTagDialogOpen] = useState(false)
  const [currentDate, setCurrentDate] = useState(new Date())
  const [selectedDate, setSelectedDate] = useState(new Date())
  const [currentView, setCurrentView] = useState<"month" | "week" | "day" | "list">("month")
  const [selectedEventId, setSelectedEventId] = useState<string | null>(null)
  const [selectedTagId, setSelectedTagId] = useState<string | null>(null)
  const [tagName, setTagName] = useState("")
  const [tagColor, setTagColor] = useState("#3788d8")
  const [isEditingTag, setIsEditingTag] = useState(false)
  const [reminderHours, setReminderHours] = useState("")
  const [reminderMinutes, setReminderMinutes] = useState("")

  // Add after other state declarations
  const [customSound, setCustomSound] = useState<File | null>(null)
  const [customSoundUrl, setCustomSoundUrl] = useState<string>("")

  const [newEvent, setNewEvent] = useState({
    id: "",
    title: "",
    description: "",
    start: "",
    end: "",
    allDay: false,
    reminderTime: null as number | null,
    reminderType: "before" as "before" | "after" | "on-time",
    reminderValue: 15,
    reminderUnit: "minutes" as "minutes" | "hours" | "days",
    color: "#3788d8",
    tagId: null as string | null,
    customSoundUrl: null as string | null,
  })

  // Get days for the current month view
  const getDaysForMonthView = () => {
    const start = startOfMonth(currentDate)
    const end = endOfMonth(currentDate)
    const days = eachDayOfInterval({ start, end })

    // Get the day of the week for the first day (0 = Sunday, 1 = Monday, etc.)
    const startDay = getDay(start)

    // Add days from the previous month to fill the first row
    const previousMonthDays = Array.from({ length: startDay }, (_, i) => addDays(start, -(startDay - i)))

    // Get the day of the week for the last day
    const endDay = getDay(end)

    // Add days from the next month to fill the last row
    const nextMonthDays = Array.from({ length: 6 - endDay }, (_, i) => addDays(end, i + 1))

    return [...previousMonthDays, ...days, ...nextMonthDays]
  }

  // Get days for the current week view
  const getDaysForWeekView = () => {
    const start = startOfWeek(currentDate)
    const end = endOfWeek(currentDate)
    return eachDayOfInterval({ start, end })
  }

  // Filter events for a specific day
  const getEventsForDay = (day: Date) => {
    return events.filter((event) => {
      const eventDate = new Date(event.startDate)
      return isSameDay(eventDate, day)
    })
  }

  // Filter events for the selected date
  const getEventsForSelectedDate = () => {
    return events.filter((event) => {
      const eventDate = new Date(event.startDate)
      return isSameDay(eventDate, selectedDate)
    })
  }

  // Filter events for the current week
  const getEventsForWeek = () => {
    return events.filter((event) => {
      const eventDate = new Date(event.startDate)
      return isSameWeek(eventDate, currentDate)
    })
  }

  // Filter events for the current month
  const getEventsForMonth = () => {
    return events.filter((event) => {
      const eventDate = new Date(event.startDate)
      return isSameMonth(eventDate, currentDate)
    })
  }

  // Filter events by tag
  const getEventsByTag = (tagId: string) => {
    return events.filter((event) => event.tagId === tagId)
  }

  // Navigate to today
  const goToToday = () => {
    setCurrentDate(new Date())
    setSelectedDate(new Date())
  }

  // Navigate to previous month/week/day
  const goToPrevious = () => {
    if (currentView === "month") {
      setCurrentDate(subMonths(currentDate, 1))
    } else if (currentView === "week") {
      setCurrentDate(addDays(currentDate, -7))
    } else if (currentView === "day") {
      setCurrentDate(addDays(currentDate, -1))
      setSelectedDate(addDays(currentDate, -1))
    }
  }

  // Navigate to next month/week/day
  const goToNext = () => {
    if (currentView === "month") {
      setCurrentDate(addMonths(currentDate, 1))
    } else if (currentView === "week") {
      setCurrentDate(addDays(currentDate, 7))
    } else if (currentView === "day") {
      setCurrentDate(addDays(currentDate, 1))
      setSelectedDate(addDays(currentDate, 1))
    }
  }

  // Handle date selection
  const handleDateClick = (day: Date) => {
    setSelectedDate(day)
    if (currentView === "month") {
      // If clicking on a day in a different month, navigate to that month
      if (!isSameMonth(day, currentDate)) {
        setCurrentDate(day)
      }
    }
  }

  // Open event dialog for a specific day
  const openNewEventDialog = (day: Date) => {
    setSelectedDate(day)
    setNewEvent({
      id: "",
      title: "",
      description: "",
      start: new Date(day).toISOString(),
      end: "",
      allDay: false,
      reminderTime: null,
      reminderType: "before",
      reminderValue: 15,
      reminderUnit: "minutes",
      color: "#3788d8",
      tagId: selectedTagId,
      customSoundUrl: null,
    })
    setReminderHours("")
    setReminderMinutes("")
    setIsEventDialogOpen(true)
  }

  // Open event dialog for editing an existing event
  const openEditEventDialog = (eventId: string) => {
    const event = events.find((e) => e.id === eventId)
    if (event) {
      // Calculate reminder values if a reminder is set
      let reminderType: "before" | "after" | "on-time" = "before"
      let reminderValue = 15
      let reminderUnit: "minutes" | "hours" | "days" = "minutes"
      let hours = ""
      let minutes = ""

      if (event.reminderTime) {
        const eventTime = event.startDate
        const reminderDate = new Date(event.reminderTime)

        // Always set hours and minutes from the reminder time
        hours = reminderDate.getHours().toString().padStart(2, "0")
        minutes = reminderDate.getMinutes().toString().padStart(2, "0")

        if (event.reminderTime === eventTime) {
          reminderType = "on-time"
          reminderValue = 0
        } else {
          const diff = eventTime - event.reminderTime

          if (diff > 0) {
            // Reminder is before event
            reminderType = "before"
            if (diff >= 24 * 60 * 60 * 1000) {
              reminderUnit = "days"
              reminderValue = Math.round(diff / (24 * 60 * 60 * 1000))
            } else if (diff >= 60 * 60 * 1000) {
              reminderUnit = "hours"
              reminderValue = Math.round(diff / (60 * 60 * 1000))
            } else {
              reminderUnit = "minutes"
              reminderValue = Math.round(diff / (60 * 1000))
            }
          } else {
            // Reminder is after event
            reminderType = "after"
            const absDiff = Math.abs(diff)
            if (absDiff >= 24 * 60 * 60 * 1000) {
              reminderUnit = "days"
              reminderValue = Math.round(absDiff / (24 * 60 * 60 * 1000))
            } else if (absDiff >= 60 * 60 * 1000) {
              reminderUnit = "hours"
              reminderValue = Math.round(absDiff / (60 * 60 * 1000))
            } else {
              reminderUnit = "minutes"
              reminderValue = Math.round(absDiff / (60 * 1000))
            }
          }
        }
      }

      setNewEvent({
        id: event.id,
        title: event.title,
        description: event.description || "",
        start: new Date(event.startDate).toISOString(),
        end: event.endDate ? new Date(event.endDate).toISOString() : "",
        allDay: event.isAllDay,
        reminderTime: event.reminderTime,
        reminderType,
        reminderValue,
        reminderUnit,
        color: event.color,
        tagId: event.tagId,
        customSoundUrl: event.customSoundUrl || null,
      })
      setReminderHours(hours)
      setReminderMinutes(minutes)
      setSelectedEventId(event.id)
      setIsEventDialogOpen(true)

      setCustomSoundUrl(event.customSoundUrl || "")
    }
  }

  // Calculate reminder time based on settings
  const calculateReminderTime = (eventStart: number): number | null => {
    // If manual time is set, use that
    if (reminderHours && reminderMinutes) {
      const hours = Number.parseInt(reminderHours)
      const minutes = Number.parseInt(reminderMinutes)

      if (!isNaN(hours) && !isNaN(minutes) && hours >= 0 && hours <= 23 && minutes >= 0 && minutes <= 59) {
        const reminderDate = new Date(eventStart)
        reminderDate.setHours(hours, minutes, 0, 0)
        return reminderDate.getTime()
      }
    }

    // If "on-time" is selected, return the event start time
    if (newEvent.reminderType === "on-time") {
      return eventStart
    }

    if (!newEvent.reminderValue) return null

    let reminderTime: number

    if (newEvent.reminderType === "before") {
      if (newEvent.reminderUnit === "minutes") {
        reminderTime = eventStart - newEvent.reminderValue * 60 * 1000
      } else if (newEvent.reminderUnit === "hours") {
        reminderTime = eventStart - newEvent.reminderValue * 60 * 60 * 1000
      } else {
        // days
        reminderTime = eventStart - newEvent.reminderValue * 24 * 60 * 60 * 1000
      }
    } else {
      // after
      if (newEvent.reminderUnit === "minutes") {
        reminderTime = eventStart + newEvent.reminderValue * 60 * 1000
      } else if (newEvent.reminderUnit === "hours") {
        reminderTime = eventStart + newEvent.reminderValue * 60 * 60 * 1000
      } else {
        // days
        reminderTime = eventStart + newEvent.reminderValue * 24 * 60 * 60 * 1000
      }
    }

    return reminderTime
  }

  // Create or update an event
  const handleSaveEvent = () => {
    if (!newEvent.title.trim()) {
      toast.error("Event title is required")
      return
    }

    // Use the selected date for the event time
    const eventDate = new Date(selectedDate)
    // Set the time to current time if creating a new event
    if (!selectedEventId) {
      const now = new Date()
      eventDate.setHours(now.getHours(), now.getMinutes(), 0, 0)
    }

    const eventStart = eventDate.getTime()
    const reminderTime = calculateReminderTime(eventStart)

    let customSoundUrlToSave = null

    // If we have a new custom sound, create an object URL
    if (customSound) {
      customSoundUrlToSave = URL.createObjectURL(customSound)
      setCustomSoundUrl(customSoundUrlToSave)
    } else if (customSoundUrl) {
      // Keep existing custom sound URL
      customSoundUrlToSave = customSoundUrl
    }

    const eventData = {
      title: newEvent.title,
      description: newEvent.description,
      startDate: eventStart,
      endDate: null, // No end time needed
      isAllDay: false,
      reminderTime,
      color: newEvent.color,
      tagId: selectedTagId, // Use the currently selected tag
      customSoundUrl: customSoundUrlToSave,
    }

    if (selectedEventId) {
      // Update existing event
      updateEvent(selectedEventId, eventData)
      toast.success("Event updated")
    } else {
      // Create new event
      addEvent(eventData)
      toast.success("Event created")
    }

    // Reset form and close dialog
    resetEventForm()
    setIsEventDialogOpen(false)
  }

  // Delete an event
  const handleDeleteEvent = () => {
    if (selectedEventId) {
      deleteEvent(selectedEventId)
      toast.success("Event deleted")
      resetEventForm()
      setIsDeleteDialogOpen(false)
      setIsEventDialogOpen(false)
    }
  }

  // Reset the event form
  const resetEventForm = () => {
    setNewEvent({
      id: "",
      title: "",
      description: "",
      start: "",
      end: "",
      allDay: false,
      reminderTime: null,
      reminderType: "before",
      reminderValue: 15,
      reminderUnit: "minutes",
      color: "#3788d8",
      tagId: null,
      customSoundUrl: null,
    })
    setReminderHours("")
    setReminderMinutes("")
    setSelectedEventId(null)
    setCustomSound(null)
    setCustomSoundUrl("")
  }

  // Handle tag operations
  const handleCreateTag = () => {
    if (!tagName.trim()) {
      toast.error("Tag name is required")
      return
    }

    if (isEditingTag && selectedTagId) {
      updateTag(selectedTagId, { name: tagName, color: tagColor })
      toast.success("Tag updated")
    } else {
      addTag({ name: tagName, color: tagColor, type: "folder" })
      toast.success("Tag created")
    }

    setTagName("")
    setTagColor("#3788d8")
    setIsEditingTag(false)
    setSelectedTagId(null)
    setIsTagDialogOpen(false)
  }

  const handleEditTag = (tagId: string) => {
    const tag = tags.find((t) => t.id === tagId)
    if (tag) {
      setTagName(tag.name)
      setTagColor(tag.color || "#3788d8")
      setSelectedTagId(tagId)
      setIsEditingTag(true)
      setIsTagDialogOpen(true)
    }
  }

  const handleDeleteTag = (tagId: string) => {
    // Update all events with this tag to have no tag
    events.forEach((event) => {
      if (event.tagId === tagId) {
        updateEvent(event.id, { tagId: null })
      }
    })

    deleteTag(tagId)
    toast.success("Tag deleted")
  }

  // Schedule notifications for reminders
  useEffect(() => {
    const checkReminders = () => {
      const now = Date.now()
      events.forEach((event) => {
        if (event.reminderTime && Math.abs(event.reminderTime - now) < 60000) {
          // If reminder time is within the next minute
          toast("Reminder", {
            description: event.title,
            duration: 10000,
          })

          // Play notification sound
          try {
            // Use custom sound if available for this event
            const soundUrl = event.customSoundUrl || "/notification.mp3"
            const audio = new Audio(soundUrl)
            audio.play().catch((e) => {
              console.log("Audio play failed:", e)
              // Fallback to default sound if custom sound fails
              if (event.customSoundUrl) {
                new Audio("/notification.mp3").play().catch(console.error)
              }
            })
          } catch (e) {
            console.log("Audio play failed:", e)
          }
        }
      })
    }

    // Check for reminders every 10 seconds instead of every minute
    const intervalId = setInterval(checkReminders, 10000)
    checkReminders() // Check immediately on mount or when events change

    return () => clearInterval(intervalId)
  }, [events])

  // Render the month view
  const renderMonthView = () => {
    const days = getDaysForMonthView()
    const dayNames = ["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"]

    return (
      <div className="h-full flex flex-col">
        <div className="grid grid-cols-7 gap-1 mb-2">
          {dayNames.map((day) => (
            <div key={day} className="text-center font-medium py-2">
              {day}
            </div>
          ))}
        </div>
        <div className="grid grid-cols-7 gap-1 flex-1">
          {days.map((day, index) => {
            const dayEvents = getEventsForDay(day)
            const isCurrentMonth = isSameMonth(day, currentDate)
            const isSelected = isSameDay(day, selectedDate)
            const isCurrentDay = isToday(day)

            return (
              <div
                key={index}
                className={`border rounded-md p-1 min-h-[100px] ${
                  isCurrentMonth ? "bg-white" : "bg-gray-50 text-gray-400"
                } ${isSelected ? "ring-2 ring-blue-500" : ""} ${
                  isCurrentDay ? "bg-blue-50" : ""
                } hover:bg-gray-50 cursor-pointer transition-colors`}
                onClick={() => handleDateClick(day)}
              >
                <div className="flex justify-between items-center mb-1">
                  <span className={`text-sm ${isCurrentDay ? "font-bold text-blue-600" : ""}`}>{format(day, "d")}</span>
                  <Button
                    variant="ghost"
                    size="icon"
                    className="h-5 w-5 rounded-full"
                    onClick={(e) => {
                      e.stopPropagation()
                      openNewEventDialog(day)
                    }}
                  >
                    <Plus className="h-3 w-3" />
                  </Button>
                </div>
                <ScrollArea className="h-[80px]">
                  {dayEvents.map((event) => (
                    <div
                      key={event.id}
                      className="text-xs mb-1 p-1 rounded truncate flex items-center"
                      style={{ backgroundColor: event.color, color: "white" }}
                      onClick={(e) => {
                        e.stopPropagation()
                        openEditEventDialog(event.id)
                      }}
                    >
                      {event.reminderTime && <Bell className="h-2 w-2 mr-1 flex-shrink-0" />}
                      <span className="truncate">
                        {event.isAllDay ? "All Day: " : ""}
                        {event.title}
                      </span>
                    </div>
                  ))}
                </ScrollArea>
              </div>
            )
          })}
        </div>
      </div>
    )
  }

  // Render the week view
  const renderWeekView = () => {
    const days = getDaysForWeekView()
    const hours = Array.from({ length: 24 }, (_, i) => i)

    return (
      <div className="h-full flex flex-col">
        <div className="grid grid-cols-8 gap-1 mb-2">
          <div className="text-center font-medium py-2"></div>
          {days.map((day, index) => (
            <div key={index} className="text-center font-medium py-2">
              <div>{format(day, "EEE")}</div>
              <div className={`text-sm ${isToday(day) ? "font-bold text-blue-600" : ""}`}>{format(day, "d")}</div>
            </div>
          ))}
        </div>
        <ScrollArea className="flex-1">
          <div className="grid grid-cols-8 gap-1">
            {hours.map((hour) => (
              <React.Fragment key={hour}>
                <div className="text-right pr-2 text-xs text-gray-500 h-12 border-t">
                  {hour === 0 ? "00:00" : `${hour.toString().padStart(2, "0")}:00`}
                </div>
                {days.map((day, dayIndex) => {
                  const hourEvents = events.filter((event) => {
                    const eventDate = new Date(event.startDate)
                    return isSameDay(eventDate, day) && eventDate.getHours() === hour
                  })

                  return (
                    <div
                      key={dayIndex}
                      className="border-t h-12 relative"
                      onClick={() => {
                        const newDate = new Date(day)
                        newDate.setHours(hour)
                        openNewEventDialog(newDate)
                      }}
                    >
                      {hourEvents.map((event) => (
                        <div
                          key={event.id}
                          className="absolute inset-0 m-1 p-1 rounded text-xs text-white overflow-hidden flex items-center"
                          style={{ backgroundColor: event.color }}
                          onClick={(e) => {
                            e.stopPropagation()
                            openEditEventDialog(event.id)
                          }}
                        >
                          {event.reminderTime && <Bell className="h-2 w-2 mr-1 flex-shrink-0" />}
                          <span className="truncate">{event.title}</span>
                        </div>
                      ))}
                    </div>
                  )
                })}
              </React.Fragment>
            ))}
          </div>
        </ScrollArea>
      </div>
    )
  }

  // Render the day view
  const renderDayView = () => {
    const hours = Array.from({ length: 24 }, (_, i) => i)
    const dayEvents = getEventsForSelectedDate()

    return (
      <div className="h-full flex flex-col">
        <div className="text-center font-medium py-4">
          <div className="text-xl">{format(selectedDate, "EEEE")}</div>
          <div className={`text-lg ${isToday(selectedDate) ? "font-bold text-blue-600" : ""}`}>
            {format(selectedDate, "MMMM d, yyyy")}
          </div>
        </div>
        <ScrollArea className="flex-1">
          <div className="grid grid-cols-1 gap-1">
            {hours.map((hour) => {
              const hourEvents = dayEvents.filter((event) => {
                const eventDate = new Date(event.startDate)
                return eventDate.getHours() === hour
              })

              return (
                <div key={hour} className="grid grid-cols-[80px_1fr] border-t">
                  <div className="text-right pr-4 py-2 text-sm text-gray-500">
                    {hour.toString().padStart(2, "0")}:00
                  </div>
                  <div
                    className="min-h-[60px] relative"
                    onClick={() => {
                      const newDate = new Date(selectedDate)
                      newDate.setHours(hour)
                      openNewEventDialog(newDate)
                    }}
                  >
                    {hourEvents.map((event) => (
                      <div
                        key={event.id}
                        className="absolute inset-x-0 m-1 p-2 rounded text-white"
                        style={{ backgroundColor: event.color }}
                        onClick={(e) => {
                          e.stopPropagation()
                          openEditEventDialog(event.id)
                        }}
                      >
                        <div className="font-medium flex items-center">
                          {event.reminderTime && <Bell className="h-3 w-3 mr-1 flex-shrink-0" />}
                          {event.title}
                        </div>
                        {event.description && <div className="text-sm mt-1">{event.description}</div>}
                        {event.tagId && (
                          <div className="mt-1 flex items-center">
                            <TagIcon className="h-3 w-3 mr-1" />
                            <span className="text-xs">{tags.find((t) => t.id === event.tagId)?.name}</span>
                          </div>
                        )}
                      </div>
                    ))}
                  </div>
                </div>
              )
            })}
          </div>
        </ScrollArea>
      </div>
    )
  }

  // Render the list view
  const renderListView = () => {
    const monthEvents = selectedTagId ? getEventsByTag(selectedTagId) : getEventsForMonth()

    // Group events by date
    const eventsByDate: Record<string, typeof events> = {}

    monthEvents.forEach((event) => {
      const dateKey = format(new Date(event.startDate), "yyyy-MM-dd")
      if (!eventsByDate[dateKey]) {
        eventsByDate[dateKey] = []
      }
      eventsByDate[dateKey].push(event)
    })

    // Sort dates
    const sortedDates = Object.keys(eventsByDate).sort()

    return (
      <div className="h-full flex flex-col">
        <div className="text-center font-medium py-4">
          <div className="text-xl">
            {selectedTagId
              ? `${tags.find((t) => t.id === selectedTagId)?.name} Events`
              : format(currentDate, "MMMM yyyy")}
          </div>
          <div className="text-sm text-gray-500">Events List</div>
        </div>
        <ScrollArea className="flex-1">
          {sortedDates.length > 0 ? (
            <div className="space-y-4 p-2">
              {sortedDates.map((dateKey) => {
                const date = parseISO(dateKey)
                return (
                  <div key={dateKey} className="border rounded-md overflow-hidden">
                    <div className={`p-2 font-medium ${isToday(date) ? "bg-blue-100" : "bg-gray-100"}`}>
                      {format(date, "EEEE, MMMM d, yyyy")}
                    </div>
                    <div className="divide-y">
                      {eventsByDate[dateKey].map((event) => (
                        <div
                          key={event.id}
                          className="p-3 hover:bg-gray-50 cursor-pointer"
                          onClick={() => openEditEventDialog(event.id)}
                        >
                          <div className="flex items-start">
                            <div
                              className="w-3 h-full min-h-[1rem] rounded-sm mr-3 mt-1"
                              style={{ backgroundColor: event.color }}
                            ></div>
                            <div className="flex-1">
                              <div className="flex items-center justify-between">
                                <div className="font-medium flex items-center">
                                  {event.reminderTime && <Bell className="h-3 w-3 mr-1 text-gray-500" />}
                                  {event.title}
                                </div>
                                <div className="flex space-x-1">
                                  <Button
                                    variant="ghost"
                                    size="icon"
                                    className="h-6 w-6"
                                    onClick={(e) => {
                                      e.stopPropagation()
                                      openEditEventDialog(event.id)
                                    }}
                                  >
                                    <Edit className="h-3 w-3" />
                                  </Button>
                                  <Button
                                    variant="ghost"
                                    size="icon"
                                    className="h-6 w-6 text-red-500"
                                    onClick={(e) => {
                                      e.stopPropagation()
                                      setSelectedEventId(event.id)
                                      setIsDeleteDialogOpen(true)
                                    }}
                                  >
                                    <Trash2 className="h-3 w-3" />
                                  </Button>
                                </div>
                              </div>
                              <div className="text-sm text-gray-500">
                                {event.isAllDay ? "All day" : format(new Date(event.startDate), "HH:mm")}
                              </div>
                              {event.description && (
                                <div className="text-sm mt-1 text-gray-600">{event.description}</div>
                              )}
                              {event.tagId && (
                                <div className="mt-1 flex items-center text-xs text-gray-500">
                                  <TagIcon className="h-3 w-3 mr-1" />
                                  {tags.find((t) => t.id === event.tagId)?.name}
                                </div>
                              )}
                            </div>
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>
                )
              })}
            </div>
          ) : (
            <div className="flex items-center justify-center h-full text-gray-500">
              {selectedTagId ? "No events with this tag" : "No events for this month"}
            </div>
          )}
        </ScrollArea>
      </div>
    )
  }

  // Render the tags sidebar
  const renderTagsSidebar = () => {
    return (
      <div className="w-64 border-r bg-gray-50 flex flex-col">
        <div className="p-4 border-b flex justify-between items-center">
          <h3 className="font-medium">Tags</h3>
          <Button
            variant="ghost"
            size="icon"
            className="h-6 w-6"
            onClick={() => {
              setTagName("")
              setTagColor("#3788d8")
              setIsEditingTag(false)
              setSelectedTagId(null)
              setIsTagDialogOpen(true)
            }}
          >
            <Plus className="h-4 w-4" />
          </Button>
        </div>
        <ScrollArea className="flex-1">
          <div className="p-2 space-y-1">
            <Button
              variant={!selectedTagId ? "secondary" : "ghost"}
              className="w-full justify-start text-sm"
              onClick={() => setSelectedTagId(null)}
            >
              All Events
            </Button>
            {tags.map((tag) => (
              <div key={tag.id} className="flex items-center group">
                <Button
                  variant={selectedTagId === tag.id ? "secondary" : "ghost"}
                  className="w-full justify-start text-sm"
                  onClick={() => setSelectedTagId(tag.id)}
                >
                  <div className="w-3 h-3 rounded-full mr-2" style={{ backgroundColor: tag.color || "#3788d8" }}></div>
                  {tag.name}
                </Button>
                <div className="hidden group-hover:flex">
                  <Button variant="ghost" size="icon" className="h-6 w-6" onClick={() => handleEditTag(tag.id)}>
                    <Edit className="h-3 w-3" />
                  </Button>
                  <Button
                    variant="ghost"
                    size="icon"
                    className="h-6 w-6 text-red-500"
                    onClick={() => handleDeleteTag(tag.id)}
                  >
                    <Trash2 className="h-3 w-3" />
                  </Button>
                </div>
              </div>
            ))}
          </div>
        </ScrollArea>
      </div>
    )
  }

  return (
    <div className="flex h-full bg-white">
      {/* Tags Sidebar */}
      {renderTagsSidebar()}

      {/* Main Calendar Area */}
      <div className="flex-1 flex flex-col">
        <div className="p-4 flex justify-between items-center border-b">
          <div className="flex items-center gap-2">
            <div className="flex border rounded-md overflow-hidden">
              <Button variant="ghost" size="sm" onClick={goToPrevious} className="rounded-none border-r">
                <ChevronLeft className="h-4 w-4" />
              </Button>
              <Button variant="ghost" size="sm" onClick={goToNext} className="rounded-none">
                <ChevronRight className="h-4 w-4" />
              </Button>
            </div>
            <Button variant="outline" onClick={goToToday}>
              today
            </Button>
            <h2 className="text-xl font-medium ml-4">
              {currentView === "day" ? format(selectedDate, "MMMM d, yyyy") : format(currentDate, "MMMM yyyy")}
            </h2>
          </div>
          <div className="flex items-center gap-2">
            <Button variant={currentView === "month" ? "secondary" : "outline"} onClick={() => setCurrentView("month")}>
              month
            </Button>
            <Button variant={currentView === "week" ? "secondary" : "outline"} onClick={() => setCurrentView("week")}>
              week
            </Button>
            <Button variant={currentView === "day" ? "secondary" : "outline"} onClick={() => setCurrentView("day")}>
              day
            </Button>
            <Button variant={currentView === "list" ? "secondary" : "outline"} onClick={() => setCurrentView("list")}>
              list
            </Button>
          </div>
          <Button
            onClick={() => {
              setNewEvent({
                id: "",
                title: "",
                description: "",
                start: new Date().toISOString(),
                end: "",
                allDay: false,
                reminderTime: null,
                reminderType: "before",
                reminderValue: 15,
                reminderUnit: "minutes",
                color: "#3788d8",
                tagId: selectedTagId,
                customSoundUrl: null,
              })
              setReminderHours("")
              setReminderMinutes("")
              setIsEventDialogOpen(true)
            }}
          >
            <Plus className="h-4 w-4 mr-2" /> Add Event
          </Button>
        </div>

        <div className="flex-1 p-4">
          <AnimatePresence mode="wait">
            <motion.div
              key={currentView + (selectedTagId || "all")}
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              transition={{ duration: 0.2 }}
              className="h-full"
            >
              {currentView === "month" && renderMonthView()}
              {currentView === "week" && renderWeekView()}
              {currentView === "day" && renderDayView()}
              {currentView === "list" && renderListView()}
            </motion.div>
          </AnimatePresence>
        </div>
      </div>

      {/* Add/Edit Event Dialog */}
      <Dialog
        open={isEventDialogOpen}
        onOpenChange={(open) => {
          if (!open) resetEventForm()
          setIsEventDialogOpen(open)
        }}
      >
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle>{selectedEventId ? "Edit Event" : "Create New Event"}</DialogTitle>
          </DialogHeader>
          <div className="space-y-4 py-2">
            <div className="space-y-2">
              <Label htmlFor="title">Title</Label>
              <Input
                id="title"
                placeholder="Event title"
                value={newEvent.title}
                onChange={(e) => setNewEvent({ ...newEvent, title: e.target.value })}
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="description">Description (optional)</Label>
              <Textarea
                id="description"
                placeholder="Event description"
                value={newEvent.description}
                onChange={(e) => setNewEvent({ ...newEvent, description: e.target.value })}
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="color">Color</Label>
              <div className="flex flex-wrap gap-2">
                {["#3788d8", "#f44336", "#4CAF50", "#FF9800", "#9C27B0", "#795548"].map((color) => (
                  <div
                    key={color}
                    className={`w-8 h-8 rounded-full cursor-pointer border-2 ${
                      newEvent.color === color ? "border-black" : "border-transparent"
                    }`}
                    style={{ backgroundColor: color }}
                    onClick={() => setNewEvent({ ...newEvent, color })}
                  />
                ))}
              </div>
            </div>

            <div className="space-y-2">
              <Label htmlFor="reminder">Set reminder</Label>
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-2">
                <Select
                  value={newEvent.reminderType}
                  onValueChange={(value: "before" | "after" | "on-time") =>
                    setNewEvent({ ...newEvent, reminderType: value })
                  }
                >
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="before">Before</SelectItem>
                    <SelectItem value="on-time">On time</SelectItem>
                    <SelectItem value="after">After</SelectItem>
                  </SelectContent>
                </Select>

                {newEvent.reminderType !== "on-time" && (
                  <>
                    <Input
                      type="number"
                      min="1"
                      value={newEvent.reminderValue}
                      onChange={(e) =>
                        setNewEvent({
                          ...newEvent,
                          reminderValue: Number.parseInt(e.target.value) || 15,
                        })
                      }
                    />

                    <Select
                      value={newEvent.reminderUnit}
                      onValueChange={(value: "minutes" | "hours" | "days") =>
                        setNewEvent({ ...newEvent, reminderUnit: value })
                      }
                    >
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="minutes">Minutes</SelectItem>
                        <SelectItem value="hours">Hours</SelectItem>
                        <SelectItem value="days">Days</SelectItem>
                      </SelectContent>
                    </Select>
                  </>
                )}
              </div>

              <div className="mt-4">
                <Label htmlFor="manual-time">Manual time (24-hour format)</Label>
                <div className="flex items-center mt-1">
                  <Input
                    id="hours"
                    type="text"
                    placeholder="15"
                    className="w-16 text-center"
                    maxLength={2}
                    value={reminderHours}
                    onChange={(e) => {
                      const hours = e.target.value.replace(/[^0-9]/g, "")
                      if (hours === "" || (Number.parseInt(hours) >= 0 && Number.parseInt(hours) <= 23)) {
                        setReminderHours(hours)
                      }
                    }}
                  />
                  <span className="mx-2 text-gray-500">:</span>
                  <Input
                    id="minutes"
                    type="text"
                    placeholder="10"
                    className="w-16 text-center"
                    maxLength={2}
                    value={reminderMinutes}
                    onChange={(e) => {
                      const minutes = e.target.value.replace(/[^0-9]/g, "")
                      if (minutes === "" || (Number.parseInt(minutes) >= 0 && Number.parseInt(minutes) <= 59)) {
                        setReminderMinutes(minutes)
                      }
                    }}
                  />
                </div>
              </div>

              {reminderHours && reminderMinutes && (
                <div className="flex items-center mt-2 text-xs text-gray-500">
                  <AlertCircle className="h-3 w-3 mr-1" />
                  Reminder will be set at exactly {reminderHours}:{reminderMinutes}
                </div>
              )}

              {!reminderHours &&
                !reminderMinutes &&
                newEvent.reminderValue > 0 &&
                newEvent.reminderType !== "on-time" && (
                  <div className="flex items-center mt-2 text-xs text-gray-500">
                    <AlertCircle className="h-3 w-3 mr-1" />
                    Reminder will be set for {newEvent.reminderValue} {newEvent.reminderUnit} {newEvent.reminderType}{" "}
                    the event
                  </div>
                )}

              {!reminderHours && !reminderMinutes && newEvent.reminderType === "on-time" && (
                <div className="flex items-center mt-2 text-xs text-gray-500">
                  <AlertCircle className="h-3 w-3 mr-1" />
                  Reminder will be set exactly at the event time
                </div>
              )}
            </div>

            {/* Add this inside the dialog content, after the reminder section */}
            <div className="space-y-2 mt-4">
              <Label htmlFor="custom-sound">Custom Notification Sound</Label>
              <div
                className="border-2 border-dashed rounded-md p-4 text-center cursor-pointer hover:bg-gray-50 transition-colors"
                onDragOver={(e) => {
                  e.preventDefault()
                  e.stopPropagation()
                }}
                onDrop={(e) => {
                  e.preventDefault()
                  e.stopPropagation()
                  if (e.dataTransfer.files && e.dataTransfer.files[0]) {
                    const file = e.dataTransfer.files[0]
                    if (file.type.startsWith("audio/")) {
                      setCustomSound(file)
                      toast.success(`Sound "${file.name}" added`)
                    } else {
                      toast.error("Please drop an audio file")
                    }
                  }
                }}
                onClick={() => {
                  const input = document.createElement("input")
                  input.type = "file"
                  input.accept = "audio/*"
                  input.onchange = (e) => {
                    const file = (e.target as HTMLInputElement).files?.[0]
                    if (file) {
                      setCustomSound(file)
                      toast.success(`Sound "${file.name}" added`)
                    }
                  }
                  input.click()
                }}
              >
                {customSound ? (
                  <div className="flex items-center justify-center gap-2">
                    <Bell className="h-4 w-4 text-blue-500" />
                    <span>{customSound.name}</span>
                    <Button
                      variant="ghost"
                      size="icon"
                      className="h-6 w-6 ml-2"
                      onClick={(e) => {
                        e.stopPropagation()
                        setCustomSound(null)
                        setCustomSoundUrl("")
                      }}
                    >
                      <Trash2 className="h-3 w-3" />
                    </Button>
                  </div>
                ) : customSoundUrl ? (
                  <div className="flex items-center justify-center gap-2">
                    <Bell className="h-4 w-4 text-blue-500" />
                    <span>Custom sound set</span>
                    <Button
                      variant="ghost"
                      size="icon"
                      className="h-6 w-6 ml-2"
                      onClick={(e) => {
                        e.stopPropagation()
                        setCustomSound(null)
                        setCustomSoundUrl("")
                      }}
                    >
                      <Trash2 className="h-3 w-3" />
                    </Button>
                  </div>
                ) : (
                  <>
                    <Bell className="h-6 w-6 mx-auto mb-2 text-gray-400" />
                    <p className="text-sm text-gray-500">Drag and drop an audio file here or click to browse</p>
                  </>
                )}
              </div>
            </div>
          </div>
          <DialogFooter className="flex justify-between">
            <div>
              {selectedEventId && (
                <Button variant="destructive" onClick={() => setIsDeleteDialogOpen(true)}>
                  Delete
                </Button>
              )}
            </div>
            <div className="flex gap-2">
              <Button
                variant="outline"
                onClick={() => {
                  resetEventForm()
                  setIsEventDialogOpen(false)
                }}
              >
                Cancel
              </Button>
              <Button onClick={handleSaveEvent}>{selectedEventId ? "Update" : "Create"}</Button>
            </div>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Delete Confirmation Dialog */}
      <Dialog open={isDeleteDialogOpen} onOpenChange={setIsDeleteDialogOpen}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle>Delete Event</DialogTitle>
          </DialogHeader>
          <div className="py-4">
            <p>Are you sure you want to delete this event? This action cannot be undone.</p>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setIsDeleteDialogOpen(false)}>
              Cancel
            </Button>
            <Button variant="destructive" onClick={handleDeleteEvent}>
              Delete
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Tag Dialog */}
      <Dialog open={isTagDialogOpen} onOpenChange={setIsTagDialogOpen}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle>{isEditingTag ? "Edit Tag" : "Create Tag"}</DialogTitle>
          </DialogHeader>
          <div className="space-y-4 py-2">
            <div className="space-y-2">
              <Label htmlFor="tag-name">Name</Label>
              <Input
                id="tag-name"
                placeholder="Tag name"
                value={tagName}
                onChange={(e) => setTagName(e.target.value)}
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="tag-color">Color</Label>
              <div className="flex gap-2">
                {["#3788d8", "#f44336", "#4CAF50", "#FF9800", "#9C27B0", "#795548"].map((color) => (
                  <div
                    key={color}
                    className={`w-8 h-8 rounded-full cursor-pointer border-2 ${
                      tagColor === color ? "border-black" : "border-transparent"
                    }`}
                    style={{ backgroundColor: color }}
                    onClick={() => setTagColor(color)}
                  />
                ))}
              </div>
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setIsTagDialogOpen(false)}>
              Cancel
            </Button>
            <Button onClick={handleCreateTag}>{isEditingTag ? "Update" : "Create"}</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  )
}
