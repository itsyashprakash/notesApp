import NotesApp from "@/components/notes-app"

export default function Home() {
  return (
    <main className="min-h-screen">
      <NotesApp />
    </main>
  )
}
